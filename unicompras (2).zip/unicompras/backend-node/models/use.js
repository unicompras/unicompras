const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');

const User = sequelize.define('User', {
    nome_admin: {
        type: DataTypes.STRING
    },
    senha: {
        type: DataTypes.STRING
    }
});

module.exports = User;