const express = require('express');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');

const router = express.Router();

router.post('/login', async (req, res) => {

    const { cnpj, senha } = req.body;

    // lógica login

    const token = jwt.sign(
        { cnpj },
        process.env.JWT_SECRET,
        { expiresIn: '1d' }
    );

    res.json({
        token
    });
});

module.exports = router;